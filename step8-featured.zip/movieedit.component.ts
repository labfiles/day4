import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-movieedit',
  template: `
    <p>
      movieedit works!
    </p>
  `,
  styles: []
})
export class MovieeditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-heroadd',
  template: `
    <p> movie works! </p>
  `,
  styles: []
})
export class MovieComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

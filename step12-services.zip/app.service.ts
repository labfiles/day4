export class AppService{
    data = ["Batman","Spiderman","Thor","Dead Pool","Hulk"]
    num = 0;
    constructor(){
        this.num = Math.round(Math.random() * 100)
    }
    getData(){
        return this.data
    }
}
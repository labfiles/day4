import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-superman',
  template: `
    <p>
      superman works!
    </p>
    <hr>
    <ul>
      <li> <a [routerLink]="['/']" routerLinkActive="selectedlink" [routerLinkActiveOptions]="{exact:true}" >Home</a> </li>
      <li> <a [routerLink]="['/batman']" routerLinkActive="selectedlink" >Batman</a> </li>
      <li> <a [routerLink]="['/superman']" routerLinkActive="selectedlink" >Superman</a> </li>
      <li> <a [routerLink]="['/ironman', '100']" routerLinkActive="selectedlink" >Ironman</a> </li>
      <li> <a [routerLink]="['/spiderman']" routerLinkActive="selectedlink" >Spiderman</a> </li>
      <li> <a [routerLink]="['/Joker']" routerLinkActive="selectedlink" >Joker</a> </li>
  </ul>
  `,
  styles: []
})
export class SupermanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
